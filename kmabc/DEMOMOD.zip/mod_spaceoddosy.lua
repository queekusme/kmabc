import "QueekusPlugins.kmabc.kmapi";

SO = { 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9 };
identifyer = "SpaceOddosy";
ModID = kmapi.getNextFreeId()

space_oddosy_buttons =	{
				modpath ..button.lyricalbasic,		-- image not created
				modpath ..button.lyricalhover,		-- image not created 
				modpath ..identifyer ..button.compactbasic,		-- Works
				modpath ..button.compacthover,		-- image not created
				modpath ..button.musicbasic,		-- image not created
				modpath ..button.musichover,		-- image not created
				modpath ..button.playbasic,		-- image not created
				modpath ..button.playhover,		-- image not created
				modpath ..button.playstartbasic,		-- image not created
				modpath ..button.playstarthover,		-- image not created
				modpath ..button.playsyncbasic,		-- image not created
				modpath ..button.playsynchover		-- image not created
			}
			
space_oddosy_package =	{
				colour = SO,
				language = ModID,
				buttons = space_oddosy_buttons
			}	

Lang[ModID]={}; -- Space Oddosy
Lang[ModID][1]="Khazad M ABC ";
Lang[ModID][2]="/plugins load lyrical";
Lang[ModID][3]="NOT(C)2012 Queekusme Coding";
Lang[ModID][4]="EnterSongName";
Lang[ModID][5]="Multipart No.";
Lang[ModID][6]="/play ";
Lang[ModID][7]="/playstart";
Lang[ModID][8]="/music";
Lang[ModID][9]="/kmabc compact";
Lang[ModID][10]=" sync";
Lang[ModID][11]="Enter Any Notes You Need Into This Box...\n\n Help command: /kmabc ";
Lang[ModID][12]="KMABC: Loaded Successfully";
Lang[ModID][13]="--KM - ABC Player Chat Commands--";
Lang[ModID][14]="------------version 1.3-------------";
Lang[ModID][15]="-Commands:";
Lang[ModID][16]="-/kmabc [show|hide|toggle|compact|clearplaylist]";
Lang[ModID][17]="Colour Schemes:";
Lang[ModID][18]="";
Lang[ModID][19]="RECENTLY PLAYED SONGS:";
Lang[ModID][20]="/lyrical toggle";
Lang[ModID][21]="Save";
Lang[ModID][22]="Load";
Lang[ModID][23]="Read the API text file\n to add more languages!";
Lang[ModID][24]="Your Instruments Here:";
Lang[ModID][25]="Playlist Cleared Successfully!";
Lang[ModID][26]="show";
Lang[ModID][27]="hide";
Lang[ModID][28]="toggle";
Lang[ModID][29]="compact";
Lang[ModID][30]="clearplaylist";
Lang[ModID][31]="";
Lang[ModID][32]="";
Lang[ModID][33]="";
Lang[ModID][34]="";
Lang[ModID][35]="";
Lang[ModID][36]="";
Lang[ModID][37]="KMABC Options:";
Lang[ModID][38]="Colour";
Lang[ModID][39]="Language:";
Lang[ModID][40]="CUSTOM";
Lang[ModID][41]="Show Lyrical Button";
Lang[ModID][42]="Read the API text file\n to add more colours!";
Lang[ModID][43]="Blue";
Lang[ModID][44]="Red";
Lang[ModID][45]="Grey";
Lang[ModID][46]="Violet";
Lang[ModID][47]="Brown";
Lang[ModID][48]="Rainbow";
Lang[ModID][49]="Clear All Quickslots";
Lang[ModID][50]="ARE YOU SURE?";
Lang[ModID][51]="Clear Entire Songlist";
Lang[ModID][52]="Buttons:";
Lang[ModID][53]="Package:";
Lang[ModID][54]="Default";

SpaceOddesy = {
				loadmod = function()
					kmapi.addToTable( "colour", "Space Oddosy", SO );					-- Adds Custom Color
					kmapi.addToTable( "language", "Space Oddosy", ModID );					-- Adds Custom Language
					kmapi.addToTable( "buttons", "Space Oddosy", space_oddosy_buttons )			-- Adds Custom Buttons	

					kmapi.package( "2001 - A Space Oddosy", space_oddosy_package )				-- Displays All Above In A Neat Little Package
					
					kmapi.addSongs({"TEST"})								-- Adding 1 song
					kmapi.addSongs({"2001 A Space Oddosy2","2001 A Space Oddosy3","2001 A Space Oddosy4"})	-- Adding Multiple Songs

					kmapi.console.text("2001 A Space Oddosy Mod, Installed Correctly")			-- Indicates We Loaded correctly
				end
	      }
